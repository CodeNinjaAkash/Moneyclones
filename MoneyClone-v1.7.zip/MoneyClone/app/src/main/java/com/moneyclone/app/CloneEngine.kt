package com.moneyclone.app
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import android.widget.Toast

/** Plug-in point: later add VirtualEngine for 15+ copies of one app. */
interface CloneEngine {
    fun ready(c: Context): Boolean
    fun setup(a: Activity)
    fun create(c: Context, pkg: String): String   // returns status message
    fun open(c: Context, pkg: String)
    fun delete(c: Context, pkg: String)
}

object WorkProfileEngine : CloneEngine {
    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    private fun dpm(c: Context) = c.getSystemService(DevicePolicyManager::class.java)
    private fun la(c: Context) = c.getSystemService(LauncherApps::class.java)

    /** User apps, including system apps that were updated by the user (Chrome, YouTube...). */
    fun isUserApp(ai: ApplicationInfo) = (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

    /** Opens Android's App info page for the clone (inside the work profile). */
    fun appInfo(c: Context, pkg: String) {
        try {
            val u = cloneUser(c) ?: return; val l = la(c)
            val a = l.getActivityList(pkg, u).firstOrNull() ?: return
            l.startAppDetailsActivity(a.componentName, u, null, null)
        } catch (e: Exception) { Toast.makeText(c, "Could not open App info: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    /** True when this copy of MoneyClone runs INSIDE the work profile. */
    fun isWork(c: Context) = dpm(c).isProfileOwnerApp(c.packageName)

    /** The user that holds the clones: the work profile (must contain MoneyClone itself). */
    fun cloneUser(c: Context): UserHandle? {
        val me = Process.myUserHandle()
        if (isWork(c)) return me
        return try { val l = la(c); l.profiles.firstOrNull { it != me && l.getActivityList(c.packageName, it).isNotEmpty() } } catch (e: Exception) { null }
    }

    /** Clones = user-installed launchable apps inside the work profile. Returns (package, label). */
    fun list(c: Context): List<Pair<String, String>> {
        val u = cloneUser(c) ?: return emptyList()
        return try {
            la(c).getActivityList(null, u)
                .filter { isUserApp(it.applicationInfo) && it.applicationInfo.packageName != c.packageName }
                .map { Pair(it.applicationInfo.packageName, it.label.toString()) }.distinctBy { it.first }
        } catch (e: Exception) { emptyList() }
    }

    fun openWorkCopy(c: Context): Boolean {
        if (isWork(c)) return true
        return try {
            val u = cloneUser(c) ?: return false
            val a = la(c).getActivityList(c.packageName, u).firstOrNull() ?: return false
            la(c).startMainActivity(a.componentName, u, null, null); true
        } catch (e: Exception) { false }
    }

    override fun ready(c: Context) = cloneUser(c) != null

    override fun setup(a: Activity) {
        if (a.getSystemService(android.os.UserManager::class.java).userProfiles.size > 1)
            Toast.makeText(a, "A work profile may already exist. If setup fails, turn Work mode ON in quick settings.", Toast.LENGTH_LONG).show()
        try {
            val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
                .putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin(a))
            a.startActivityForResult(i, 1)
        } catch (e: Exception) { Toast.makeText(a, "This phone blocked work-profile setup: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    override fun create(c: Context, pkg: String): String {
        if (!isWork(c)) return "Open the MoneyClone copy inside your work profile (briefcase icon) and clone from there."
        val d = dpm(c)
        runCatching { d.setApplicationHidden(admin(c), pkg, false) }
        return try { if (d.installExistingPackage(admin(c), pkg)) "Cloned" else "Android refused to clone this app" }
        catch (e: Exception) { "Failed: ${e.message}" }
    }

    override fun open(c: Context, pkg: String) {
        try {
            val u = cloneUser(c) ?: return; val l = la(c)
            l.getActivityList(pkg, u).firstOrNull()?.let { l.startMainActivity(it.componentName, u, null, null) }
        } catch (e: Exception) { Toast.makeText(c, "Could not open: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    override fun delete(c: Context, pkg: String) {
        if (isWork(c)) runCatching { dpm(c).setApplicationHidden(admin(c), pkg, true) }
    }
}
