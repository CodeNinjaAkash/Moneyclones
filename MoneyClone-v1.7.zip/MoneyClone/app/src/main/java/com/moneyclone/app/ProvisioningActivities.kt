package com.moneyclone.app
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.os.Build
import android.os.Bundle

/** Android 10+ asks the admin app which mode to use during work-profile setup. */
class ProvisioningModeActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val r = Intent()
        if (Build.VERSION.SDK_INT >= 31) r.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE, DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE)
        setResult(RESULT_OK, r); finish()
    }
}
class ComplianceActivity : Activity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setResult(RESULT_OK); finish() }
}
